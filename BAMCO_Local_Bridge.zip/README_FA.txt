1) فایل ZIP را Extract All کنید.
2) Install_And_Start_BAMCO_Bridge.bat را یک‌بار اجرا کنید.
3) Outlook دسکتاپ را باز نگه دارید.
4) اگر Chrome اجازه Local network access خواست، Allow را بزنید.

پس از نصب، رابط BAMCO همراه ویندوز به‌صورت خودکار اجرا می‌شود.
