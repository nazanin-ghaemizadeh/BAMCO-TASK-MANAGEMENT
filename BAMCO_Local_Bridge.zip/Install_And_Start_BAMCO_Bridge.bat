@echo off
setlocal
chcp 65001 >nul
title BAMCO Local Bridge Setup
set "TARGET=%LOCALAPPDATA%\BAMCO_TASK_MANAGEMENT_BRIDGE"
set "BASE=https://raw.githubusercontent.com/nazanin-ghaemizadeh/BAMCO-TASK-MANAGEMENT/main"

echo.
echo ==============================================
echo   BAMCO TASK MANAGEMENT - Local Bridge Setup
echo ==============================================
echo.

where py >nul 2>nul
if errorlevel 1 (
  echo Python Launcher ^(py^) was not found.
  echo Install Python 3 and run this installer again.
  pause
  exit /b 1
)

if not exist "%TARGET%" mkdir "%TARGET%"
if not exist "%TARGET%\bridge_parts" mkdir "%TARGET%\bridge_parts"
if not exist "%TARGET%\core_b64" mkdir "%TARGET%\core_b64"

echo Downloading BAMCO bridge files...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; $base='%BASE%'; $target='%TARGET%'; $files=@('outlook_bridge.py','sticker-default.js','bridge_parts/bridge_01.part','bridge_parts/bridge_02.part','core_b64/core_01.b64','core_b64/core_02.b64','core_b64/core_03.b64','core_b64/core_04.b64','core_b64/core_05.b64','core_b64/core_06.b64','core_b64/core_07.b64','core_b64/core_08.b64'); foreach($f in $files){$dest=Join-Path $target ($f -replace '/','\'); $dir=Split-Path $dest; New-Item -ItemType Directory -Force -Path $dir | Out-Null; Invoke-WebRequest -UseBasicParsing -Uri ($base+'/'+$f) -OutFile $dest}"
if errorlevel 1 (
  echo Download failed. Check internet access and run this installer again.
  pause
  exit /b 1
)

> "%TARGET%\Start_BAMCO_Bridge.bat" echo @echo off
>> "%TARGET%\Start_BAMCO_Bridge.bat" echo chcp 65001 ^>nul
>> "%TARGET%\Start_BAMCO_Bridge.bat" echo cd /d "%%~dp0"
>> "%TARGET%\Start_BAMCO_Bridge.bat" echo py outlook_bridge.py

echo Installing required Python packages...
py -m pip install --user --upgrade pywin32 Pillow msoffcrypto-tool openpyxl
if errorlevel 1 (
  echo Package installation failed. Check internet access and try again.
  pause
  exit /b 1
)

echo Creating automatic startup shortcut...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ws=New-Object -ComObject WScript.Shell; $lnk=$ws.CreateShortcut([Environment]::GetFolderPath('Startup')+'\BAMCO Local Bridge.lnk'); $lnk.TargetPath='%TARGET%\Start_BAMCO_Bridge.bat'; $lnk.WorkingDirectory='%TARGET%'; $lnk.WindowStyle=7; $lnk.Save()" >nul 2>nul

echo Starting BAMCO Local Bridge...
start "BAMCO Local Bridge" /min "%TARGET%\Start_BAMCO_Bridge.bat"
timeout /t 3 /nobreak >nul
start "" "https://nazanin-ghaemizadeh.github.io/BAMCO-TASK-MANAGEMENT/"

echo.
echo Setup completed.
echo Keep Outlook desktop available while using email features.
echo If Chrome asks for Local network access, choose Allow.
echo.
pause
endlocal
