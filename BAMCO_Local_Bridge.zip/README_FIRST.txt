BAMCO TASK MANAGEMENT - Windows Bridge

1) Extract this ZIP to a normal folder.
2) Open Outlook desktop and keep it running.
3) Double-click Start_Outlook_Bridge.bat.
4) The first run downloads the current bridge files and installs required Python packages if needed.
5) If Chrome asks for Local network access, choose Allow.
6) Keep the Bridge window open while using the GitHub Pages app.

The website remains the main app. This local bridge only gives the browser permission to use the local TM Excel file and Outlook desktop.
